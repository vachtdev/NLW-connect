# HTML

- Hypertext
- Markup
- Language

# CSS

- Cascading
- Style
- Sheet

# JavaScript

- Linguagem Interpretada pelo Browser
- Multiparadigmas

## Conceitos fundamentais de programa;'ao

Comentários
Declaração de variáveis (const, let)
Operadores (atribuição, concatenação, matemática)
Tipos de dados (string, number, boolean, date)
Estrutura de dados (functions, object, array)
Controle de fluxo (if/else)
Estrutura de repetição (for)
Manipulação e gestão dos dados
Conversão de dados

## Algoritmo
Sequencia de passos lógica e finmita para resolução de um problema

## Fases de resolução de um problema

Coletar os dados
Processar os dados
Apresentar os dados

'''JavaScript
// Comentários variáveis, tipos de dados e funções
const corBola ="azul" + "escuro" // azulescuro
const idade = 10 + 2 // 12

// arrow function
const soma = (a, b) =>{
  return a + b
}


const resultado = soma("alo", 32)
alert(resultado)
'''